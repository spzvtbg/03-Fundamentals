﻿using System;
using System.Linq;

public class Program
{
    public static void Main()
    {
        var first = Console.ReadLine().Split();
        var t1 = new CustomTuple<string, string>();
        t1.Key = string.Join(" ", first.Take(first.Length - 1));
        t1.Value = first.Last();

        var second = Console.ReadLine().Split();
        var t2 = new CustomTuple<string, int>();
        t2.Key = string.Join(" ", second.Take(second.Length - 1));
        t2.Value = int.Parse(second.Last());

        var third = Console.ReadLine().Split();
        var t3 = new CustomTuple<int, double>();
        t3.Key = int.Parse(third[0]);
        t3.Value = double.Parse(third[1]);

        Console.WriteLine(t1);
        Console.WriteLine(t2);
        Console.WriteLine(t3);
    }
}
