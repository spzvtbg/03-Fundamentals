﻿using System;

public class Program
{
    //// System.String
    //public static void Main()
    //{
    //    var lines = int.Parse(Console.ReadLine());

    //    for (int count = 0; count < lines; count++)
    //    {
    //        Console.WriteLine(new Box<string>(Console.ReadLine()).ToString());
    //    }
    //}

    // System.Int32
    public static void Main()
    {
        var lines = int.Parse(Console.ReadLine());

        for (int count = 0; count < lines; count++)
        {
            Console.WriteLine(new Box<int>(int.Parse(Console.ReadLine())).ToString());
        }
    }
}
