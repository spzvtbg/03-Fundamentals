﻿namespace P03_BarraksWars.Models.Units
{
    using _03BarracksFactory.Models.Units;

    public class Gunner : Unit
    {
        public Gunner() : base(health: 20, attackDamage: 20)
        {
        }
    }
}
