﻿using System.Reflection;

namespace P01_HarvestingFields
{
    public class HarvestingFieldsTest
    {
        public static void Main()
        {
            var commandHolder = new CommandHolder(typeof(HarvestingFields));
            var commandInterpreter = new CommandInterpreter(commandHolder);
            commandInterpreter.StartExecuting();

            //var fields = typeof(HarvestingFields)
            //    .GetFields(
            //      BindingFlags.Instance
            //    | BindingFlags.FlattenHierarchy
            //    | BindingFlags.NonPublic);

            //foreach (var field in fields)
            //{
            //    System.Console.WriteLine(field.Name + ":");
            //    var fieldProperties = typeof(FieldInfo).GetProperties();

            //    System.Console.WriteLine(" Properties:");
            //    foreach (var item in fieldProperties)
            //    {
            //        System.Console.WriteLine($"   {item.Name} -> {item.GetValue(field)}");
            //    }
            //}
        }
    }
}
