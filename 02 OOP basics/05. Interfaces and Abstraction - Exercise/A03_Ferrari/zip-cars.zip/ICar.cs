﻿public interface ICar
{
    string Driver { get; }

    string Model { get; }

    string Break { get; }

    string Gas { get; }
}
