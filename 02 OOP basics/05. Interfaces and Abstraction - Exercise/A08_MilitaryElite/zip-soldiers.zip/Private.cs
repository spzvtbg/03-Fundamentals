﻿public class Private : Soldier
{
    public Private(params string[] parameters) : base(parameters)
    {
    }
}
