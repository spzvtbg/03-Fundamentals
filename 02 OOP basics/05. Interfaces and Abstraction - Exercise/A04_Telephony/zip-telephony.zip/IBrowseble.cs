﻿public interface IBrowseble
{
    string[] Urls { get; }
}
