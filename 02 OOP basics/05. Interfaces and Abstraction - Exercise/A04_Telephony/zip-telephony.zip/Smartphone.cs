﻿public class Smartphone : Phone
{
    public Smartphone(string[] numbers, string[] urls) : base(numbers, urls)
    {
    }
}
