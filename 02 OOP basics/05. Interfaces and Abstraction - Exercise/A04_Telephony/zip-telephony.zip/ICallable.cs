﻿public interface ICallable
{
   string[] Numbers { get; }
}
