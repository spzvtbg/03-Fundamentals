﻿public interface IAddRemoveCollection
{
    int Add(string item); // To start

    string Remove(); // Last
}