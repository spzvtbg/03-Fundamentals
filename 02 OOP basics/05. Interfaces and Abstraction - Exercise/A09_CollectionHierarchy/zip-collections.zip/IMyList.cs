﻿public interface IMyList
{
    int Add(string item); // To start

    string Remove(); // From start

    int Used(); // Count elements
}