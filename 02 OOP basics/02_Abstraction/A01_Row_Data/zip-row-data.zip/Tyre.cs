﻿public class Tyre
{
    public Tyre(int age, double presure)
    {
        this.Age = age;
        this.Pressure = presure;
    }

    public int Age { get; set; }

    public double Pressure { get; set; }
}
