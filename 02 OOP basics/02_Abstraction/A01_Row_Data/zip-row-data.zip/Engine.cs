﻿public class Engine
{
    public Engine(int power, int speed)
    {
        this.Power = power;
        this.Speed = speed;
    }

    public int Power { get; set; }

    public int Speed { get; set; }
}
