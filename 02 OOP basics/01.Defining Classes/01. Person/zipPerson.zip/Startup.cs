﻿public class Startup
{
    public static void Main()
    {
        Person pesho = new Person("Pesho", 20);
        Person gosho = new Person("Gosho", 18);
        Person stamet = new Person("Stamat", 43);
    }
}
