﻿public class Engine
{
    public Engine(int power, int speed)
    {
        this.EnginePower = power;
        this.EngineSpeed = speed;
    }

    public int EnginePower { get; set; }

    public int EngineSpeed { get; set; }
}